﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

// ゲーム全体を管理する
[NetworkSettings(sendInterval = 0)]
public class GameController : NetworkBehaviour
{
    public enum State
    {
        WaitOtherPlayerConnect, /* 他プレイヤーの参加待ち */
        Inputting, /* 入力中 */
        Result, /* 結果表示 */
    }

    [SyncVar(hook = "OnStateChanged")]
    State m_State = State.WaitOtherPlayerConnect;

    // ゲームの状況を表す画像リソース
    [SerializeField] Sprite m_WaitingSprite; // 「対戦相手募集中」
    [SerializeField] Sprite m_InputtingSprite; // 「じゃん…けん…」
    [SerializeField] Sprite m_ResultSprite; // 「ぽん!!」

    // ゲームの状況を表示するImageの参照
    Image m_StatusImage;

    // グー・チョキ・パーボタンを制御するコンポーネント
    JankenButtons m_JankenButtons;

    // Resultとなった瞬間の時間（Resultを終えるタイミングの判定に使う）
    float m_ResultStartTime;

    void Start()
    {
        m_StatusImage = GameObject.Find("StatusImage").GetComponent<Image>();
        m_JankenButtons = FindObjectOfType<JankenButtons>();
        OnStateChanged(m_State);
    }

    // Updateはサーバーでのみ行う
    [ServerCallback]
    void Update()
    {
        // 長くなってしまうので、Update処理は、状態別に分けた
        switch (m_State)
        {
            case State.WaitOtherPlayerConnect:
                UpdateWaitOtherPlayerConnect();
                break;
            case State.Inputting:
                UpdateInputting();
                break;
            case State.Result:
                UpdateResult();
                break;
            default:
                Debug.LogError("想定外のGameState:" + m_State);
                break;
        }
    }

    // 他のプレイヤーの接続を待っているときのUpdate
    [Server]
    void UpdateWaitOtherPlayerConnect()
    {
        // Ready状態のプレイヤーの数を数え、2以上の場合は対戦を開始する
        int readyPlayerCount = 0;

        foreach (Player player in FindObjectsOfType<Player>())
        {
            if (player.m_State == Player.State.Ready)
            {
                readyPlayerCount++;
            }
        }

        if (readyPlayerCount > 1)
        {
            ChangeGameState(State.Inputting);
        }
    }

    // 各プレイヤーが入力中のときのUpdate
    [Server]
    void UpdateInputting()
    {
        Player[] players = FindObjectsOfType<Player>();

        // 入力中状態のときに、他プレイヤーが離脱して
        // プレイヤー数が1になった（自分だけとなった）場合は、
        // 他のプレイヤー待機状態に戻る
        if (players.Length == 1)
        {
            ChangeGameState(State.WaitOtherPlayerConnect);
            players[0].ChangeState(Player.State.Ready);
            return;
        }

        // 入力中状態のときに新規接続してきたプレイヤーをInputting状態にしてあげる
        foreach (Player player in players)
        {
            if (player.m_State == Player.State.Ready)
            {
                player.ChangeState(Player.State.Inputting);
            }
        }

        // 未入力のプレイヤーがいる場合は、勝敗判定せず終了
        foreach (Player player in players)
        {
            if (player.m_State != Player.State.Inputted)
            {
                return;
            }
        }

        // 全プレイヤーが入力し終わっている場合は、勝敗判定を行い、結果表示状態へ
        ChangeGameState(State.Result);

        // 場に出された全員の手の種類を調べる
        HashSet<Hand> hands = new HashSet<Hand>();

        foreach (Player player in players)
        {
            hands.Add(player.m_Hand);
        }

        // 場に出された手の種類が2種類ということは、決着が着く
        if (hands.Count == 2)
        {
            Hand winHand;

            // グーが出ていないということは、パーとチョキのみが出ていたということなので、チョキが勝ちである
            if (!hands.Contains(Hand.Guu))
                winHand = Hand.Choki;
            // チョキが出ていないということは、パーとグーのみが出ていたということなので、パーが勝ちである
            else if (!hands.Contains(Hand.Choki))
                winHand = Hand.Paa;
            // 上記に当てはまらなければ、グーが勝ちである
            else
                winHand = Hand.Guu;

            // 全プレイヤーに対して、勝ちか負けを設定する
            foreach (Player player in players)
            {
                if (player.m_Hand == winHand)
                    player.ChangeState(Player.State.Win);
                else
                    player.ChangeState(Player.State.Lose);
            }
        }
        // 場に出された手の種類が2種類でないということは、あいこである
        else
        {
            // 全プレイヤーをあいこ状態にする
            foreach (Player player in players)
            {
                player.ChangeState(Player.State.Aiko);
            }
        }
    }

    // 結果表示状態のときのUpdate
    [Server]
    void UpdateResult()
    {
        // Result表示後、一定時間経過したら、入力状態にする
        if (Time.time >= m_ResultStartTime + 3f)
        {
            ChangeGameState(State.Inputting);
        }
    }

    // 状態を変更する
    [Server]
    void ChangeGameState(State state)
    {
        // m_GameStateを変更すれば、あとはhookによりOnStateChangedが実行される
        m_State = state;
    }

    // GameStateが変更されたときのhook
    void OnStateChanged(State state)
    {
        m_State = state;

        switch (m_State)
        {
            case State.WaitOtherPlayerConnect:
                m_StatusImage.sprite = m_WaitingSprite;
                m_JankenButtons.SetVisibility(false);
                break;
            case State.Inputting:
                m_StatusImage.sprite = m_InputtingSprite;
                m_JankenButtons.SetVisibility(true);
                if (isServer)
                {
                    // 全プレイヤーをInputting状態にする
                    // ※ただしInitializing状態（初期化完了していない状態）のものは除く
                    foreach (Player player in FindObjectsOfType<Player>())
                    {
                        if (player.m_State != Player.State.Initializing)
                            player.ChangeState(Player.State.Inputting);
                    }
                }
                break;
            case State.Result:
                m_StatusImage.sprite = m_ResultSprite;
                m_ResultStartTime = Time.time; // Resultになった時刻を覚えておく
                break;
            default:
                Debug.LogError("想定外のGameState:" + m_State);
                break;
        }
    }
}
