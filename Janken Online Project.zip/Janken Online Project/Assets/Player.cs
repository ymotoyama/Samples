﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

// プレイヤー1人分の表示を管理する。
// あとは選んだ手をCommandでサーバーへ送信する。
[NetworkSettings(sendInterval = 0)]
public class Player : NetworkBehaviour
{
    // タイトル画面で入力されたプレイヤー名
    public static string s_LocalPlayerName = "名無しさん";

    // プレイヤーの状態種別
    public enum State
    {
        Initializing, /* 初期化中 */
        Ready, /* 準備完了、待機中 */
        Inputting, /* 手 入力中 */
        Inputted, /* 手 入力完了 */
        Win, /* 勝った */
        Lose, /* 負けた */
        Aiko, /* あいこ */
    }

    // プレイヤーの状態
    [SyncVar(hook = "OnStateChanged")]
    public State m_State = State.Initializing;

    // プレイヤーの画像
    [SerializeField] Sprite m_NormalSprite;
    [SerializeField] Sprite m_InputtingSprite;
    [SerializeField] Sprite m_InputtedSprite;
    [SerializeField] Sprite m_WinSprite;
    [SerializeField] Sprite m_LoseSprite;
    [SerializeField] Sprite m_AikoSprite;

    // 手の画像
    [SerializeField] Sprite m_GuuSprite;
    [SerializeField] Sprite m_ChokiSprite;
    [SerializeField] Sprite m_PaaSprite;

    // 手（グー・チョキ・パー）
    [SyncVar(hook = "OnHandChanged")]
    public Hand m_Hand = Hand.None;

    // プレイヤー名
    [SyncVar(hook = "OnPlayerNameChanged")]
    string m_PlayerName;

    // プレイヤー画像を表示するImageの参照
    Image m_CharacterImage;

    // 手を表示するImageの参照
    Image m_HandImage;

    // プレイヤー名Textの参照
    Text m_PlayerNameText;

    void Awake()
    {
        // プレイヤーオブジェクトはシーンのルートに生成されるので、
        // PlayerLayoutGroupの中に移動する。
        transform.SetParent(GameObject.Find("PlayerLayoutGroup").transform);

        // シーンのルートからPlayerLayoutGroupの中に移動すると、
        // CanvasScalerの絡みでScaleがおかしくなるので、Scale=1に戻す
        transform.localScale = Vector3.one;

        // 各種参照を取得する
        m_HandImage = transform.Find("HandImage").GetComponent<Image>();
        m_CharacterImage = transform.Find("CharacterImage").GetComponent<Image>();
        m_PlayerNameText = transform.Find("PlayerNameText").GetComponent<Text>();
    }

    void Start()
    {
        if (isLocalPlayer)
        {
            // プレイヤーオブジェクトは、生成された瞬間はInitializingという非表示状態である。
            // クライアントで生成されたら、それをサーバーへ通知し、
            // 状態がReadyとなる。
            // （同時にプレイヤー名も送信する）
            CmdInitialize(s_LocalPlayerName);
        }

        // 各種表示の初期化
        OnPlayerNameChanged(m_PlayerName);
        OnStateChanged(m_State);
        OnHandChanged(m_Hand);
    }

    [Command]
    void CmdInitialize(string playerName)
    {
        ChangeState(State.Ready);
        ChangePlayerName(playerName);
    }

    // プレイヤー名変更のhook
    void OnPlayerNameChanged(string name)
    {
        m_PlayerName = name;

        m_PlayerNameText.text = m_PlayerName;
    }

    // 状態変更のhook
    void OnStateChanged(State state)
    {
        m_State = state;

        // 状態に応じて、各表示を切り替える
        switch (m_State)
        {
            case State.Initializing:
                m_CharacterImage.enabled = false; // キャラ画像非表示
                m_HandImage.enabled = false; // 手を非表示に
                m_PlayerNameText.enabled = false; // プレイヤー名非表示
                break;
            case State.Ready:
                m_CharacterImage.enabled = true; // キャラ画像表示
                m_CharacterImage.sprite = m_NormalSprite; // 通常時画像
                m_PlayerNameText.enabled = true; // プレイヤー名表示
                m_HandImage.enabled = false; // 手を非表示に
                break;
            case State.Inputting:
                m_CharacterImage.sprite = m_InputtingSprite; // 考え中画像
                m_HandImage.enabled = false; // 手を非表示に
                break;
            case State.Inputted:
                m_CharacterImage.sprite = m_InputtedSprite; // 確定画像
                m_HandImage.enabled = false; // 手を非表示に
                break;
            case State.Win:
                m_CharacterImage.sprite = m_WinSprite; // WIN画像
                m_HandImage.enabled = true; // 手を表示
                break;
            case State.Lose:
                m_CharacterImage.sprite = m_LoseSprite; // LOSE画像
                m_HandImage.enabled = true; // 手を表示
                break;
            case State.Aiko:
                m_CharacterImage.sprite = m_AikoSprite; // あいこ画像
                m_HandImage.enabled = true; // 手を表示
                break;
            default:
                Debug.LogError("想定外のstate:" + m_State);
                break;
        }
    }

    // 手が変更されたときのhook
    void OnHandChanged(Hand hand)
    {
        m_Hand = hand;

        // 選ばれた手の画像を表示する
        switch (m_Hand)
        {
            case Hand.None:
                break;
            case Hand.Guu:
                m_HandImage.sprite = m_GuuSprite;
                break;
            case Hand.Choki:
                m_HandImage.sprite = m_ChokiSprite;
                break;
            case Hand.Paa:
                m_HandImage.sprite = m_PaaSprite;
                break;
            default:
                Debug.LogError("想定外の手:" + m_Hand);
                break;
        }
    }

    // 状態を変更する
    [Server]
    public void ChangeState(State state)
    {
        // m_Stateを変更すれば、あとはhookによりOnStateChangedが実行される
        m_State = state;
    }

    // プレイヤー名を変更する
    [Server]
    void ChangePlayerName(string name)
    {
        // m_PlayerNameを変更すれば、あとはhookによりOnPlayerNameChangedが実行される
        m_PlayerName = name;
    }

    // 手の入力をサーバーへ通知する
    [Command]
    public void CmdInput(Hand hand)
    {
        ChangeState(State.Inputted);
        // m_Handを変更すれば、あとはhookによりOnHandChangedが実行される
        m_Hand = hand;
    }
}
