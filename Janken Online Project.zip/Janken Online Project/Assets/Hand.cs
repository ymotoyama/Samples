﻿public enum Hand
{
    None,
    Guu,
    Choki,
    Paa,
}