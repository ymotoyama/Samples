﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

// グー・チョキ・パーのボタンの管理を行う
public class JankenButtons : MonoBehaviour
{
    GameObject m_GuuButton;
    GameObject m_ChokiButton;
    GameObject m_PaaButton;

    void Start()
    {
        // ボタンオブジェクトの参照を取得
        m_GuuButton = GameObject.Find("GuuButton");
        m_ChokiButton = GameObject.Find("ChokiButton");
        m_PaaButton = GameObject.Find("PaaButton");

        // ボタンが押された時の処理を登録
        m_GuuButton.GetComponent<Button>().onClick.AddListener(() => OnClick(Hand.Guu));
        m_ChokiButton.GetComponent<Button>().onClick.AddListener(() => OnClick(Hand.Choki));
        m_PaaButton.GetComponent<Button>().onClick.AddListener(() => OnClick(Hand.Paa));
    }

    // ボタンの表示/非表示を設定する
    public void SetVisibility(bool visible)
    {
        m_GuuButton.SetActive(visible);
        m_ChokiButton.SetActive(visible);
        m_PaaButton.SetActive(visible);
    }

    // ボタンが押された時の処理
    void OnClick(Hand hand)
    {
        // 押されたことをCommandによってサーバーへ通知する
        ClientScene.localPlayers[0].gameObject.GetComponent<Player>().CmdInput(hand);
        // ボタンを非表示にする
        SetVisibility(false);
    }
}